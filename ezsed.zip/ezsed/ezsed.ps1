start python .\ezsed.py -WindowStyle Hidden
